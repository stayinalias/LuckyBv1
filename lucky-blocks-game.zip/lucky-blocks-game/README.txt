LUCKY BLOCKS BATTLEGROUNDS - offline fan build v1.3

Play: open index.html in Chrome/Edge (or serve this folder over http).
game.js is the built bundle; src/*.js are the sources.
Rebuild the bundle with: python3 build.py
